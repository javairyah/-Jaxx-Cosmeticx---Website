<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}



$errorMSG = "";





/* MESSAGE-TEXT */
if (empty($_POST["message_text"])) {
    $errorMSG .= "<li>Message is required</li>";
} 
else {
    $message_text = $_POST["message_text"];
}




if(empty($errorMSG))
{
$sql = "INSERT INTO contact (message_text)
VALUES ('$message_text')";

if ($conn->query($sql) === TRUE) {
  $msg =  "Message Sent successfully.";

   echo json_encode(['code'=>200, 'msg'=>$msg]);
    exit;
  
} 
else 
{
  
    echo json_encode(['code'=>404, 'msg'=>$conn->error]);
}
    
}
else 
{
    
      echo json_encode(['code'=>404, 'msg'=>$errorMSG]);
}




?>
