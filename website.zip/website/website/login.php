<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}



$errorMSG = "";





/* EMAIL */
if (empty($_POST["email"])) {
    $errorMSG .= "<li>Email/Phone Number is required</li>";
} 
else {
    $email = $_POST["email"];
}

/* password */
if (empty($_POST["password"])) {
    $errorMSG .= "<li>password is required</li>";
} else {
    $password = $_POST["password"];
}


if(empty($errorMSG))
{
$sql = "INSERT INTO login (email,password)
VALUES ('$email','$password')";

if ($conn->query($sql) === TRUE) {
  $msg =  "Login successfully.";

   echo json_encode(['code'=>200, 'msg'=>$msg]);
    exit;
  
} 
else 
{
  
    echo json_encode(['code'=>404, 'msg'=>$conn->error]);
}
    
}
else 
{
    
      echo json_encode(['code'=>404, 'msg'=>$errorMSG]);
}




?>
