-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2021 at 06:58 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `band`
--

CREATE TABLE `band` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `band`
--

INSERT INTO `band` (`id`, `name`, `price`) VALUES
(109, 'Head Band - pink', 499);

-- --------------------------------------------------------

--
-- Table structure for table `band1`
--

CREATE TABLE `band1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `band1`
--

INSERT INTO `band1` (`id`, `name`, `price`) VALUES
(110, 'Head Band - White', 499);

-- --------------------------------------------------------

--
-- Table structure for table `blender`
--

CREATE TABLE `blender` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blender`
--

INSERT INTO `blender` (`id`, `name`, `price`) VALUES
(111, 'Blenders - Pack of 3', 999);

-- --------------------------------------------------------

--
-- Table structure for table `blender1`
--

CREATE TABLE `blender1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blender1`
--

INSERT INTO `blender1` (`id`, `name`, `price`) VALUES
(112, 'Blenders - Pack of 3', 999);

-- --------------------------------------------------------

--
-- Table structure for table `brush`
--

CREATE TABLE `brush` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brush`
--

INSERT INTO `brush` (`id`, `name`, `price`) VALUES
(113, 'Makeup Brushes - Pack of 7 Brushes', 1499);

-- --------------------------------------------------------

--
-- Table structure for table `brush1`
--

CREATE TABLE `brush1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brush1`
--

INSERT INTO `brush1` (`id`, `name`, `price`) VALUES
(114, 'Rose Pink Brush Set - Pack of 9 Brushes', 1999);

-- --------------------------------------------------------

--
-- Table structure for table `cheeks`
--

CREATE TABLE `cheeks` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cheeks`
--

INSERT INTO `cheeks` (`id`, `name`, `price`) VALUES
(115, 'Face Palette - Blush,eyebrow,contour shades', 1499);

-- --------------------------------------------------------

--
-- Table structure for table `cheeks1`
--

CREATE TABLE `cheeks1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cheeks1`
--

INSERT INTO `cheeks1` (`id`, `name`, `price`) VALUES
(116, 'Cusion Blush - Shade \"Heart\"', 1399);

-- --------------------------------------------------------

--
-- Table structure for table `cheeks2`
--

CREATE TABLE `cheeks2` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cheeks2`
--

INSERT INTO `cheeks2` (`id`, `name`, `price`) VALUES
(117, 'Cream Highlighter - Shade \"Glow\"', 1699);

-- --------------------------------------------------------

--
-- Table structure for table `eyes`
--

CREATE TABLE `eyes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eyes`
--

INSERT INTO `eyes` (`id`, `name`, `price`) VALUES
(118, 'Lash Adhesive - Pack of 1', 599);

-- --------------------------------------------------------

--
-- Table structure for table `feature1`
--

CREATE TABLE `feature1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feature1`
--

INSERT INTO `feature1` (`id`, `name`, `price`) VALUES
(119, 'Face Elite Deal', 1999);

-- --------------------------------------------------------

--
-- Table structure for table `feature2`
--

CREATE TABLE `feature2` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feature2`
--

INSERT INTO `feature2` (`id`, `name`, `price`) VALUES
(120, 'Face Pro Deal', 2399);

-- --------------------------------------------------------

--
-- Table structure for table `feature3`
--

CREATE TABLE `feature3` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feature3`
--

INSERT INTO `feature3` (`id`, `name`, `price`) VALUES
(121, 'Pack of 5 Lipstick', 1599);

-- --------------------------------------------------------

--
-- Table structure for table `feature4`
--

CREATE TABLE `feature4` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feature4`
--

INSERT INTO `feature4` (`id`, `name`, `price`) VALUES
(122, 'Pink Edition Palette', 2699);

-- --------------------------------------------------------

--
-- Table structure for table `feature5`
--

CREATE TABLE `feature5` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feature5`
--

INSERT INTO `feature5` (`id`, `name`, `price`) VALUES
(123, 'Jade Roller + Gua Sha Facial Massage Set', 3999);

-- --------------------------------------------------------

--
-- Table structure for table `feature6`
--

CREATE TABLE `feature6` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feature6`
--

INSERT INTO `feature6` (`id`, `name`, `price`) VALUES
(124, 'Rose Gold Edition Brushes', 3199);

-- --------------------------------------------------------

--
-- Table structure for table `foundation`
--

CREATE TABLE `foundation` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foundation`
--

INSERT INTO `foundation` (`id`, `name`, `price`) VALUES
(125, 'Face Contour Stick - In shade \"Coffee Brown\"', 999);

-- --------------------------------------------------------

--
-- Table structure for table `lips`
--

CREATE TABLE `lips` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lips`
--

INSERT INTO `lips` (`id`, `name`, `price`) VALUES
(126, 'Lip Gloss - Pack of 4', 1399);

-- --------------------------------------------------------

--
-- Table structure for table `lips1`
--

CREATE TABLE `lips1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lips1`
--

INSERT INTO `lips1` (`id`, `name`, `price`) VALUES
(127, 'Lipstick - Shade \"Nude Pink\"', 1399);

-- --------------------------------------------------------

--
-- Table structure for table `lips2`
--

CREATE TABLE `lips2` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lips2`
--

INSERT INTO `lips2` (`id`, `name`, `price`) VALUES
(128, 'Lip Patch - Pack of 1', 399);

-- --------------------------------------------------------

--
-- Table structure for table `nails`
--

CREATE TABLE `nails` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nails`
--

INSERT INTO `nails` (`id`, `name`, `price`) VALUES
(129, 'Fake Nails - Pack of 1', 999);

-- --------------------------------------------------------

--
-- Table structure for table `nails1`
--

CREATE TABLE `nails1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nails1`
--

INSERT INTO `nails1` (`id`, `name`, `price`) VALUES
(130, 'Fake Nails - Pack of 1', 899);

-- --------------------------------------------------------

--
-- Table structure for table `nails2`
--

CREATE TABLE `nails2` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nails2`
--

INSERT INTO `nails2` (`id`, `name`, `price`) VALUES
(131, 'Fake Nails - Pack of 1', 799);

-- --------------------------------------------------------

--
-- Table structure for table `powder`
--

CREATE TABLE `powder` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `powder`
--

INSERT INTO `powder` (`id`, `name`, `price`) VALUES
(132, 'Face Deal - Pack of Loose powder & Compact Powder', 1749);

-- --------------------------------------------------------

--
-- Table structure for table `skincare`
--

CREATE TABLE `skincare` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skincare`
--

INSERT INTO `skincare` (`id`, `name`, `price`) VALUES
(133, 'Facial Serum - Pack of 1\r\n', 1599);

-- --------------------------------------------------------

--
-- Table structure for table `skincare1`
--

CREATE TABLE `skincare1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skincare1`
--

INSERT INTO `skincare1` (`id`, `name`, `price`) VALUES
(134, 'Face Milk - Pack of 1', 1199);

-- --------------------------------------------------------

--
-- Table structure for table `skincare2`
--

CREATE TABLE `skincare2` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skincare2`
--

INSERT INTO `skincare2` (`id`, `name`, `price`) VALUES
(135, 'Sheet Mask - Pack of 1', 299);

-- --------------------------------------------------------

--
-- Table structure for table `tool`
--

CREATE TABLE `tool` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tool`
--

INSERT INTO `tool` (`id`, `name`, `price`) VALUES
(136, 'Lashe Applicator - Pack of 5', 600);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `band`
--
ALTER TABLE `band`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `band1`
--
ALTER TABLE `band1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blender`
--
ALTER TABLE `blender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blender1`
--
ALTER TABLE `blender1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brush`
--
ALTER TABLE `brush`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brush1`
--
ALTER TABLE `brush1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheeks`
--
ALTER TABLE `cheeks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheeks1`
--
ALTER TABLE `cheeks1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheeks2`
--
ALTER TABLE `cheeks2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eyes`
--
ALTER TABLE `eyes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature1`
--
ALTER TABLE `feature1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature2`
--
ALTER TABLE `feature2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature3`
--
ALTER TABLE `feature3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature4`
--
ALTER TABLE `feature4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature5`
--
ALTER TABLE `feature5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature6`
--
ALTER TABLE `feature6`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foundation`
--
ALTER TABLE `foundation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lips`
--
ALTER TABLE `lips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lips1`
--
ALTER TABLE `lips1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lips2`
--
ALTER TABLE `lips2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nails`
--
ALTER TABLE `nails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nails1`
--
ALTER TABLE `nails1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nails2`
--
ALTER TABLE `nails2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `powder`
--
ALTER TABLE `powder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skincare`
--
ALTER TABLE `skincare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skincare1`
--
ALTER TABLE `skincare1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skincare2`
--
ALTER TABLE `skincare2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tool`
--
ALTER TABLE `tool`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `band`
--
ALTER TABLE `band`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `band1`
--
ALTER TABLE `band1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `blender`
--
ALTER TABLE `blender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `blender1`
--
ALTER TABLE `blender1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `brush`
--
ALTER TABLE `brush`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `brush1`
--
ALTER TABLE `brush1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `cheeks`
--
ALTER TABLE `cheeks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `cheeks1`
--
ALTER TABLE `cheeks1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `cheeks2`
--
ALTER TABLE `cheeks2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `eyes`
--
ALTER TABLE `eyes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `feature1`
--
ALTER TABLE `feature1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `feature2`
--
ALTER TABLE `feature2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `feature3`
--
ALTER TABLE `feature3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `feature4`
--
ALTER TABLE `feature4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `feature5`
--
ALTER TABLE `feature5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `feature6`
--
ALTER TABLE `feature6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `foundation`
--
ALTER TABLE `foundation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `lips`
--
ALTER TABLE `lips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `lips1`
--
ALTER TABLE `lips1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `lips2`
--
ALTER TABLE `lips2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `nails`
--
ALTER TABLE `nails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `nails1`
--
ALTER TABLE `nails1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `nails2`
--
ALTER TABLE `nails2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `powder`
--
ALTER TABLE `powder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `skincare`
--
ALTER TABLE `skincare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `skincare1`
--
ALTER TABLE `skincare1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `skincare2`
--
ALTER TABLE `skincare2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `tool`
--
ALTER TABLE `tool`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
