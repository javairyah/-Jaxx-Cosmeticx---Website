<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");

if(isset($_POST["add_to_cart"]))
{
    if(isset($_SESSION["shopping_cart"]))
    {
        $item_array_id = array_column($_SESSION["shopping_cart"], "hidden_name");
        if(!in_array($_GET["hidden_name"], $item_array_id))
        {
            $count = count($_SESSION["shopping_cart"]);
            $item_array = array(
                'item_name'         =>  $_POST["hidden_name"],
                'item_price'        =>  $_POST["hidden_price"],
                'item_quantity'     =>  $_POST["quantity"]
            );
            $_SESSION["shopping_cart"][$count] = $item_array;
        }
        else
        {
            echo '<script>alert("Item Already Added")</script>';
        }
    }
    else
    {
        $item_array = array(
            'item_name'         =>  $_POST["hidden_name"],
            'item_price'        =>  $_POST["hidden_price"],
            'item_quantity'     =>  $_POST["quantity"]
        );
        $_SESSION["shopping_cart"][0] = $item_array;
    }
}

if(isset($_GET["action"]))
{
    if($_GET["action"] == "delete")
    {
        foreach($_SESSION["shopping_cart"] as $keys => $values)
        {
            if($values["item_id"] == $_GET["id"])
            {
                unset($_SESSION["shopping_cart"][$keys]);
                echo '<script>alert("Item Removed")</script>';
                echo '<script>window.location="cart.php"</script>';
            }
        }
    }
}

?>


<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="home.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootsrap/4.5.2/css/bootstrap.min.css" integrity="sha384-Jckb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z"
    crossorigin="anonymous">
    
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.9.1.min.js"></script>

    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Luckiest+Guy&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@300&family=Tenali+Ramakrishna&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link rel="shortcut icon" type="image/png" href="fevicon.png">
    <!-- Required meta tags -->
    

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

    <title>Product - Jaxx Cosmeticx Brand</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />



<script>
function magnify(imgID, zoom) {
  var img, glass, w, h, bw;
  img = document.getElementById(imgID);
  /*create magnifier glass:*/
  glass = document.createElement("DIV");
  glass.setAttribute("class", "img-magnifier-glass");
  /*insert magnifier glass:*/
  img.parentElement.insertBefore(glass, img);
  /*set background properties for the magnifier glass:*/
  glass.style.backgroundImage = "url('" + img.src + "')";
  glass.style.backgroundRepeat = "no-repeat";
  glass.style.backgroundSize = (img.width * zoom) + "px " + (img.height * zoom) + "px";
  bw = 3;
  w = glass.offsetWidth / 2;
  h = glass.offsetHeight / 2;
  /*execute a function when someone moves the magnifier glass over the image:*/
  glass.addEventListener("mousemove", moveMagnifier);
  img.addEventListener("mousemove", moveMagnifier);
  /*and also for touch screens:*/
  glass.addEventListener("touchmove", moveMagnifier);
  img.addEventListener("touchmove", moveMagnifier);
  function moveMagnifier(e) {
    var pos, x, y;
    /*prevent any other actions that may occur when moving over the image*/
    e.preventDefault();
    /*get the cursor's x and y positions:*/
    pos = getCursorPos(e);
    x = pos.x;
    y = pos.y;
    /*prevent the magnifier glass from being positioned outside the image:*/
    if (x > img.width - (w / zoom)) {x = img.width - (w / zoom);}
    if (x < w / zoom) {x = w / zoom;}
    if (y > img.height - (h / zoom)) {y = img.height - (h / zoom);}
    if (y < h / zoom) {y = h / zoom;}
    /*set the position of the magnifier glass:*/
    glass.style.left = (x - w) + "px";
    glass.style.top = (y - h) + "px";
    /*display what the magnifier glass "sees":*/
    glass.style.backgroundPosition = "-" + ((x * zoom) - w + bw) + "px -" + ((y * zoom) - h + bw) + "px";
  }
  function getCursorPos(e) {
    var a, x = 0, y = 0;
    e = e || window.event;
    /*get the x and y positions of the image:*/
    a = img.getBoundingClientRect();
    /*calculate the cursor's x and y coordinates, relative to the image:*/
    x = e.pageX - a.left;
    y = e.pageY - a.top;
    /*consider any page scrolling:*/
    x = x - window.pageXOffset;
    y = y - window.pageYOffset;
    return {x : x, y : y};
  }
}
</script>




  </head>
  <body>
    <div class="container-fluid-lg bg-danger text-center" style="color:white;padding: 3px 0 3px 0;">Free Shipping Over 2500 PKR</div>
<!--------------------------------------------------- Navbar Start ------------------------------------------------->

<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-dark" style="font-family:'Poppins',sans-serif">

    <div class="container-fluid">
  
      <a class="navbar-brand" href="home.html">
      
        <img src="logo.png" alt="" width="44" height="44">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto sm-2 mb-lg-0  " >
          <li class="nav-item ">
            <a class="nav-link active  " aria-current="page" href="home.html">Home</a>
          </li>
  
          <li class="nav-item dropdown" >
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Shop All
            </a>
            <ul class="dropdown-menu bg-dark  " aria-labelledby="navbarDropdown" style="color:white">
              <li><a class="dropdown-item active bg-dark" href="face.html">Face</a></li>
              <li><a class="dropdown-item active bg-dark" href="lip.php">Lips</a></li>
              <li><a class="dropdown-item active bg-dark" href="eyes.php">Eyes</a></li>
              <li><a class="dropdown-item active bg-dark" href="skincare.php">Skincare</a></li>
              <li><a class="dropdown-item active bg-dark" href="nail.php">Nails</a></li>
               
             
  
            </ul>
          </li>

          <li class="nav-item"><a class="nav-link" href="palettes.php">Palettes</a></li>
          <li class="nav-item"><a class="nav-link" href="tools.html">Tools & Brushes</a></li>
        <li class="nav-item"><a class="nav-link" href="login.html">Account</a>
          </li>
                  <li class="nav-item">
            <a class="nav-link" href="cart.php">Cart</a>
          </li>
  
  
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="search here...." aria-label="Search">
          <button class="btn btn-danger" type="submit">Search</button>
        </form>
      </div>
    </div>
  
  </nav>
  <!-------------------------------------------product page--------------------------------------------------------------->

<br><br><br>

<div class="container">

 <?php
                $query = "SELECT * FROM feature4 ORDER BY id ASC";
                $result = mysqli_query($connect, $query);
                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_array($result))
                    {
                ?>
  <div class="row ">
    <div class="col-sm-6">
<div class="img-magnifier-container">
  <img id="myimage" src="feature/4.jpeg" width="500" height="500">
</div>

</div>
 <div class="col-md-6">
    <br>
                <form method="post" action="cart.php?action=add&id=<?php echo $row["id"]; ?>">
                    <div style=" background-color:white; border-radius:5px; padding:16px;" >
                        <p style="background: #dc2828;color: white;width: 50px;padding-left: 8px;font-size: 15px;">NEW</p>

                        
                        <h1 class="text-dark" style="font-family: fantasy;"><?php echo $row["name"]; ?></h1>
<img src="star.png" class="img-responsive" style="height: 40px;width: 120px;"/><br />
<br>
                        <h4 class="text-danger">PKR <?php echo $row["price"]; ?></h4>
                        <br><br>

<p>Availabiliy: 
<span style="color: forestgreen;font-family:poppins">
In Stock</span>
</p>
<br>

Quantity: <input  type="text" name="quantity" value="1" min="1" max="100" style="width: 30px;text-decoration: none;text-align: center;font-size: 15px;" >


                        <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
<br><br>
                        <input type="submit" name="add_to_cart" style="margin-top:15px;font-size: 15px;" class="btn btn-danger" value="Add to Cart" />

                    </div>
                </form>
                
            </div><br><br>
        
        
            <?php
                    }
                }
            ?>

            
    </div>
    <br />

</div>
</div>

<script>
magnify("myimage", 2);
</script>



<br><br><br>
 
            
            
            
           

           

<!------------------------------------------------------Footer------------------------------------------------>
<footer class="container-fluid bg-grey py-5">
<div class="container">
   <div class="row">
      <div class="col-md-6">
         <div class="row">
            <div class="col-md-6 ">
               <div class="logo-part">
                  <img src="logo.png" class="w-50 logo-footer" >
                  <h6>Contact Us</h6>
                  <p>5643 Al-Noor Soceity Pakistan, AS 44000</p>
                  <p>+92XXXXXXXXXX, +92XXXXXXXXXX</p>
               </div>
            </div>
            <div class="col-md-6 px-4">
               <h6> About The Shop</h6>
               <p>Jaxx Cosmeticx Brand is one of the largest cosmetic brand of Pakistan with wide range of premium quality makeup products to provide the best value for money to the customers, Influencers and Makeup artists globally.</p>
               <a href="#" class="btn-footer" data-bs-toggle="modal" data-bs-target="#Modal" data-bs-whatever="@mdo"> Contact Us</a>
               <div class="modal fade" id="Modal" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel">Contact Us</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
        
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Message:</label>
            <textarea class="form-control" id="message_text" style="height: 300px;"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
        <button id="submit" type="button" class="btn btn-danger">Send message</button>
      </div>
    </div>
  </div>
</div>
            </div>
         </div>
      </div>
      <div class="col-md-6">
         <div class="row">
            <div class="col-md-6 px-4">
               <h6> Help</h6>
               <div class="row ">
                  <div class="col-md-6">
                     <ul style="font-size: 12px;">
                        <li> <a href="home.html"> Home</a> </li>
                        <li> <a href="about.html"> About us</a> </li>
                        <li> <a href="privacy.html"> Privacy Policy</a> </li>
                        <li> <a href="shipping.html"> Shipping & Delivery Policy</a> </li>
                        <li> <a href="term.html"> Terms & Conditions</a> </li>
                        <li> <a href="refund.html"> Refund Policy</a> </li>
                     </ul>
                  </div>
                  <div class="col-md-6 px-4">
                    <h6> Menu</h6>
               <div class="row ">
                  <div class="col-md-6">
                     <ul style="font-size: 12px;">
                        <li> <a href="face.html"> Face</a> </li>
                        <li> <a href="lip.php"> Lips</a> </li>
                        <li> <a href="eyes.php"> Eyes</a> </li>
                        <li> <a href="skincare.php"> Skincare</a> </li>
                        <li> <a href="nail.php"> Nails</a> </li>
                        <li> <a href="palettes.php"> Palettes</a> </li>
                        <li> <a href="tools.html"> Tools & Brushes</a> </li>
                     </ul>
                  </div>
               </div>
            </div></div></div>
            <div class="col-md-6 ">
               <h6> Newsletter</h6>
               <div class="social">
                  <a href="https://www.facebook.com/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                  <a href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                  <a href="https://www.youtube.com/"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                  <a href="https://www.whatsapp.com/"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
               </div>
               <form class="form-footer my-3">
                  <input type="text"  placeholder="search here...." name="search">
                  <input type="button" value="Go" >
               </form>
              
            </div>
         </div>
      </div>
   </div>
</div>
</div>
  <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
    -->

</body>
<script type="text/javascript">
  $(document).ready(function() {

  $('#submit').click(function(e){
        e.preventDefault();


    
        var message_text = $("#message_text").val();
        


        $.ajax({
            type: "POST",
            url: "contact.php",
            dataType: "json",
            data: {message_text:message_text },
            success : function(data){
                if (data.code == "200"){
                    alert("Success: " +data.msg);
                } else {
                    $(".display-error").html("<ul>"+data.msg+"</ul>");
                    $(".display-error").css("display","block");
                }
            }
        });


      });
  });
</script>
</html>