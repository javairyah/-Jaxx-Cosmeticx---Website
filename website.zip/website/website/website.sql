-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2021 at 06:51 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `bag`
--

CREATE TABLE `bag` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bag`
--

INSERT INTO `bag` (`id`, `name`, `image`, `price`) VALUES
(1, 'Makeup Bag - Color \"Skin\"\r\n ', '1.jpeg', 899),
(2, 'Makeup Bag - Pack of 1\r\n', '2.png', 799),
(3, 'Makeup Bag - Pack of 1\r\n', '3.jpeg', 1199),
(4, 'Makeup Bag - Pack of 1\r\n', '4.jpeg', 1199),
(5, 'Makeup Bag - Pack of 3\r\n', '5.jpeg', 1399),
(6, 'Makeup Bag - Color \"Copper\"\r\n', '6.jpeg', 1299),
(7, 'Makeup Bag - Pack of 4\r\n', '7.jpeg', 1899),
(8, 'Makeup Bag - Pack of 3\r\n', '8.jpeg', 2699),
(9, 'Makeup Bag - Pack of 1\r\n', '9.jpeg', 799);

-- --------------------------------------------------------

--
-- Table structure for table `band`
--

CREATE TABLE `band` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `band`
--

INSERT INTO `band` (`id`, `name`, `image`, `price`) VALUES
(10, 'Head Band - Pink\r\n', '1.jpeg', 499),
(11, 'Head Band - Blue\r\n', '2.jpeg', 399),
(12, 'Head Band - Pink\r\n', '3.jpeg', 499),
(13, 'Head Band - White\r\n', '4.jpeg', 499),
(14, 'Head Band - Pink\r\n', '5.jpeg', 499),
(15, 'Head Band - Purple\r\n', '6.jpeg', 499),
(16, 'Head Band - Blue\r\n', '7.jpg', 399),
(17, 'Head Bands - Pack of 6 \r\n', '8.png', 2199);

-- --------------------------------------------------------

--
-- Table structure for table `blender`
--

CREATE TABLE `blender` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blender`
--

INSERT INTO `blender` (`id`, `name`, `image`, `price`) VALUES
(1, 'Makeup Puff - Pack of 4\r\n ', '1.jpeg', 399),
(2, 'Blenders - Pack of 3\r\n', '2.jpeg', 999),
(3, 'Blender - Pack of 3\r\n', '3.jpeg', 999),
(4, 'Blender - Pack of 1\r\n', '4.jpeg', 999),
(5, 'Blender - Pack of 1\r\n', '5.jpeg', 799),
(6, 'Blender - Pack of 1\r\n', '6.jpg', 999),
(7, 'Blenders - Pack of 2\r\n', '7.jpeg', 999),
(8, 'Blender - Pack of 1\r\n', '8.jpeg', 999),
(9, 'Blender - Pack of 1\r\n', '9.png', 999);

-- --------------------------------------------------------

--
-- Table structure for table `brush`
--

CREATE TABLE `brush` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brush`
--

INSERT INTO `brush` (`id`, `name`, `image`, `price`) VALUES
(1, 'Rose Gold Brush Set - Pack of 7 Brushes\r\n', '1.jpeg', 1999),
(2, 'Makeup Brushes - Pack of 7 Brushes\r\n', '2.jpeg', 1499),
(3, 'Makeup Brushes - Pack of 12 Brushes\r\n', '3.jpeg', 1799),
(4, 'Makeup Brushes - Pack of 5 Brushes\r\n', '4.jpeg', 999),
(5, 'Makeup Brushes - Pack of 6 Brushes\r\n', '5.jpeg', 1499),
(6, 'Rose Pink Brush Set - Pack of 9 Brushes\r\n ', '6.jpeg', 1999),
(7, 'Makeup Brushes - Pack of 5 Brushes', '7.jpeg', 899),
(8, 'Paw Makeup Brushes - Pack of 2 Brushes\r\n', '8.jpeg', 699),
(9, 'Makeup Brushes - Pack of 8 Brushes\r\n', '9.jpeg', 1799),
(10, 'Makeup Brushes - Pack of 9 Brushes\r\n', '10.jpeg', 2199),
(11, 'Makeup Brushes - Pack of 10 Brushes\r\n', '11.jpeg', 1899),
(12, 'Mini Makeup Brushes - Pack of 2 Brushes\r\n', '12.jpeg', 499);

-- --------------------------------------------------------

--
-- Table structure for table `cheeks`
--

CREATE TABLE `cheeks` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cheeks`
--

INSERT INTO `cheeks` (`id`, `name`, `image`, `price`) VALUES
(18, 'Highlighter - \"Primistic Pearl\"', '1.jpeg', 1199),
(19, 'Cusion Blush - shade \"Heart\"\r\n', '2.jpeg', 899),
(20, 'Highlighter Deal - Pack of 2', '3.jpeg', 1449),
(21, 'Face Palette (Multipurpose)\r\n', '4.jpeg', 1499),
(22, 'Cream Blush - shade \"Rose\"\r\n', '11.png', 999),
(23, 'Highlighter Palette', '14.jpeg', 1699),
(24, 'Liquid Blush - Pack of 4', '15.jpeg', 2299),
(25, 'Powder Blush - \"Cherry\"\r\n', '16.jpeg', 749),
(26, 'Cream Highlighter - \"Glow\"\r\n', '20.jpeg', 1699),
(27, 'Highlighter - \"Champagne\"\r\n ', '21.jpeg', 1399),
(28, 'Roll On Highlighter - \"Shine\"\r\n', '22.jpeg', 1149),
(29, 'Highlighter - \"Unicorn\"\r\n', '26.jpeg', 1299);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Id` int(11) NOT NULL,
  `Message_text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Id`, `Message_text`) VALUES
(67, '888'),
(68, '77'),
(69, '121212'),
(70, 'yooo'),
(71, 'hii batool'),
(72, 'maha ');

-- --------------------------------------------------------

--
-- Table structure for table `eyes`
--

CREATE TABLE `eyes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eyes`
--

INSERT INTO `eyes` (`id`, `name`, `image`, `price`) VALUES
(30, 'Eye Lashes - Pack of 1 Eye Lashes', '1.jpeg', 1199),
(31, 'Eye Lashes - Pack of 1 Eye Lashes', '2.jpeg', 1799),
(32, 'Eyebrow Pomade - Pack of 3', '3.jpeg', 2199),
(33, 'Lash Adhesive - Pack of 1', '4.png', 599),
(34, 'Eye Pencil - Black', '7.jpeg', 899),
(35, 'Mascara - Black', '8.jpeg', 1199),
(36, 'Eye Pencil - White', '9.png', 899),
(37, 'Pen Eye Liner - Black', '11.jpeg', 1299);

-- --------------------------------------------------------

--
-- Table structure for table `foundation`
--

CREATE TABLE `foundation` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foundation`
--

INSERT INTO `foundation` (`id`, `name`, `image`, `price`) VALUES
(38, 'Liquid Foundation - Warm', '1.jpeg', 1850),
(39, 'Cusion Foundation - Warm', '2.jpeg', 1199),
(40, 'Cusion Foundation - Beige', '3.jpeg', 1599),
(41, 'Paint Stick foundation - Beige', '4.jpeg', 1299),
(42, 'CC Cream Foundation - Ivory\r\n', '5.jpeg', 1799),
(43, 'Tarte Concealer - Ivory', '6.jpeg', 1299),
(44, 'Liquid Foundation - Fair\r\n', '7.jpeg', 2299),
(45, 'Contour Stick Deal - Pack of 3\r\n', '8.jpeg', 1749),
(46, 'Face Contour Stick - Coffee Brown', '10.jpeg', 999),
(47, 'Liquid Foundation - Warm Beige', '11.jpeg', 1899),
(48, 'Face Primer - 24k Gold Primer', '16.jpeg', 1999);

-- --------------------------------------------------------

--
-- Table structure for table `lip`
--

CREATE TABLE `lip` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lip`
--

INSERT INTO `lip` (`id`, `name`, `image`, `price`) VALUES
(49, 'Peach Girl - Pack of 4 Lipsticks', '1.jpeg', 1199),
(50, 'Cat Lipstick - Watermelon', '2.jpeg', 799),
(51, 'Fantasy Lipstick - Galaxy', '3.jpeg', 1199),
(52, 'Heart Lipstick - Shade Berry', '4.jpeg', 999),
(53, 'Lipstick - Nude Pink', '22.jpeg', 1399),
(54, 'Lipstick Gloss - Unicorn', '6.jpeg', 999),
(55, 'Teayason Mini Lip Gloss - Pack of 5', '7.jpeg', 1299),
(56, 'Lip Snacker (Lip Balm) - Pack of 4', '20.jpeg', 1599),
(57, 'Mini Lip Gloss - Pack of 4', '12.jpeg', 1399),
(58, 'Lavender Lip Oil - Pack of 3', '44.jpeg', 999),
(59, 'Cleansing Gel - Pack of 1', '33.jpeg', 899),
(60, 'Naming Lip Gloss - Pack of 4', '11.jpeg', 1199);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Id`, `Email`, `Password`) VALUES
(1, 'jazz@gmail.com', 'javairya'),
(2, 'yumna@gmail.com', 'yuna'),
(3, '03065574883', 'cvnm'),
(4, 'jazz@gmail.com', '8877'),
(5, 'jinnah@gmail.com', 'jiunuu'),
(6, '03065574883', 'hhh');

-- --------------------------------------------------------

--
-- Table structure for table `nail`
--

CREATE TABLE `nail` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nail`
--

INSERT INTO `nail` (`id`, `name`, `image`, `price`) VALUES
(61, 'Fake Nails - Pack of 1', '1.jpeg', 799),
(62, 'Fake Nails - Pack of 1', '2.jpeg', 799),
(63, 'Fake Nails - Pack of 1', '3.jpeg', 799),
(64, 'Fake Nails - Pack of 1', '4.jpeg', 799),
(65, 'Fake Nails - Pack of 1', '5.jpeg', 899),
(66, 'Fake Nails - Pack of 1', '6.jpeg', 799),
(67, 'Fake Nails - Pack of 1', '7.jpeg', 599),
(68, 'Fake Nails - Pack of 1', '8.jpeg', 999),
(69, 'Fake Nails - Pack of 1', '9.jpeg', 899),
(70, 'Fake Nails - Pack of 1', '10.jpeg', 499),
(71, 'Fake Nails - Pack of 1', '11.jpeg', 999),
(72, 'Fake Nails - Pack of 1', '12.jpeg', 999);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `postal_code` int(11) NOT NULL,
  `phone_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Id`, `fname`, `lname`, `address`, `city`, `country`, `postal_code`, `phone_number`) VALUES
(1, 'javairya', 'hussain', 'house no.R721 block-18 alnoor-society,karachi', 'karachi', 'Pakistan', 0, 2147483647),
(2, 'javairya', 'hussain', 'house no.R721 block-18 alnoor-society,karachi', 'karachi', 'Pakistan', 0, 2147483647),
(3, 'noor', 'noor', 'asdfgp987654', 'karachi', 'Pakistan', 34567, 123456790),
(4, 'javairya hussain', 'kkk', 'df', 'karachi', 'Pakistan', 4446789, 2147483647),
(5, 'javairya hussain', 'kkk', 'fvb', 'karachi', 'Pakistan', 56789, 567890),
(6, 'javairya hussain', 'kkk', 'dddffg', 'karachi', 'Pakistan', 4567890, 23456789),
(7, 'javairya hussain', 'kkk', 's', 'karachi', 'Pakistan', 87542, 1595878562),
(8, 'batool', 'ehsan', 'adsfjioytfvbnklojuh', 'karachi', 'Pakistan', 1234567890, 1234567890),
(9, 'javairya', 'hussain', 'house no R721 block 18 alnoor-society,karachi', 'karachi', 'Pakistan', 123456, 2147483647),
(10, 'javairya', 'hussain', 'house no R721 block 18 alnoor-society,karachi', 'karachi', 'Pakistan', 123456, 2147483647),
(11, 'batool', 'ehsan', 'adsfjioytfvbnklojuh', 'karachi', 'Pakistan', 1234567890, 1234567890),
(12, 'maha', 'maha', 'house no R721 block 18 alnoor-society,karachi', 'karachi', 'Pakistan', 123456, 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `palettes`
--

CREATE TABLE `palettes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `palettes`
--

INSERT INTO `palettes` (`id`, `name`, `image`, `price`) VALUES
(73, 'Pink Palette ', '1.jpeg', 1299),
(74, 'Press Gliter', '2.jpeg', 799),
(75, 'Neutral Platte \r\n', '3.jpeg', 1399),
(76, 'Nightmare Palette \r\n', '4.jpeg', 999),
(77, 'Sunset Palette \r\n', '5.jpeg', 1699),
(78, 'Shimmer Palette \r\n', '6.jpeg', 1799),
(79, 'Mermaid Palette \r\n', '7.jpeg', 1299),
(80, 'Lime Palette\r\n', '8.jpeg', 999),
(81, 'Flourence Palette \r\n', '9.jpeg', 999),
(82, '$U My Baby Palette\r\n', '10.jpeg', 2199),
(83, 'Peach Puff Palette\r\n', '11.jpeg', 1199),
(84, 'Desert Dusk Palette\r\n\r\n', '12.jpeg', 2499);

-- --------------------------------------------------------

--
-- Table structure for table `powder`
--

CREATE TABLE `powder` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `powder`
--

INSERT INTO `powder` (`id`, `name`, `image`, `price`) VALUES
(85, 'Loose Powder - Banana\r\n', '1.jpeg', 1299),
(86, 'Cream Contour & Concealer Palette', '5.png', 1299),
(87, 'Face Deal - Loose & Compact Powder\r\n', '6.png', 1749),
(88, 'Compact Powder - Beige\r\n', '7.png', 1199),
(89, 'Loose Powder - Translucent\r\n', '10.jpeg', 1299),
(90, 'Powder Foundation - Nude\r\n', '25.jpeg', 1399);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Id`, `Email`, `Password`) VALUES
(1, 'jazz@gmail.com', 'javairya'),
(2, 'noor@gmail.com', 'nooorrrn'),
(3, '03065574883', 'sdfghjkl;'),
(4, '03065574883', 'ffffff'),
(5, 'jazz@gmail.com', 'jjjj');

-- --------------------------------------------------------

--
-- Table structure for table `skincare`
--

CREATE TABLE `skincare` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skincare`
--

INSERT INTO `skincare` (`id`, `name`, `image`, `price`) VALUES
(91, 'Lip Patch - Pack of 1', '1.jpeg', 399),
(92, 'Face Mask - Pack of 1', '2.jpeg', 299),
(93, 'Face Milk - Pack of 1', '3.png', 1199),
(94, 'Clay Mask - Pack of 1', '4.jpeg', 399),
(95, 'Facial Serum - Pack of 1', '5.jpeg', 1599),
(96, 'Sheet Mask - Pack of 1', '6.png', 299),
(97, 'Face Mist - Pack of 1', '7.jpeg', 1),
(98, 'Milk Bomb Mask - Pack of 5', '8.jpeg', 1299),
(99, 'Facial Kit - Pack of 4 items', '9.png', 3599),
(100, 'Sheet Mask - Pack of 3', '10.jpeg\r\n', 1199),
(101, 'Hyaluronic Serum - Pack of 1', '11.jpeg', 2299),
(102, 'Lip Balm - Pack of 3 Lip Balm ', '12.jpeg', 1299),
(103, 'Eye Patches - Pack of 1', '13.jpeg', 1599);

-- --------------------------------------------------------

--
-- Table structure for table `tool`
--

CREATE TABLE `tool` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tool`
--

INSERT INTO `tool` (`id`, `name`, `image`, `price`) VALUES
(104, 'Lashe Applicator - Pack of 5\r\n', '1.jpeg', 699),
(105, 'Facial Stones - Pack of 1\r\n', '2.jpeg', 2199),
(106, 'Travel Kit - Pack of 1\r\n', '3.jpeg', 899),
(107, 'Tweezer - Pack of 1\r\n', '4.jpeg', 199),
(108, 'Brush Cleaner - Pack of 1\r\n ', '5.jpeg', 399);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bag`
--
ALTER TABLE `bag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `band`
--
ALTER TABLE `band`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blender`
--
ALTER TABLE `blender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brush`
--
ALTER TABLE `brush`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cheeks`
--
ALTER TABLE `cheeks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `eyes`
--
ALTER TABLE `eyes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foundation`
--
ALTER TABLE `foundation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lip`
--
ALTER TABLE `lip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `nail`
--
ALTER TABLE `nail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `palettes`
--
ALTER TABLE `palettes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `powder`
--
ALTER TABLE `powder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `skincare`
--
ALTER TABLE `skincare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tool`
--
ALTER TABLE `tool`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bag`
--
ALTER TABLE `bag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `band`
--
ALTER TABLE `band`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `blender`
--
ALTER TABLE `blender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `brush`
--
ALTER TABLE `brush`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cheeks`
--
ALTER TABLE `cheeks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `eyes`
--
ALTER TABLE `eyes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `foundation`
--
ALTER TABLE `foundation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `lip`
--
ALTER TABLE `lip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `nail`
--
ALTER TABLE `nail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `palettes`
--
ALTER TABLE `palettes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `powder`
--
ALTER TABLE `powder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `skincare`
--
ALTER TABLE `skincare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `tool`
--
ALTER TABLE `tool`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
