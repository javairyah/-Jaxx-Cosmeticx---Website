<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}



$errorMSG = "";





/* First Name */
if (empty($_POST["fname"])) {
    $errorMSG .= "<li>First Name is required</li>";
} 
else {
    $fname = $_POST["fname"];
}

/* Last Name */
if (empty($_POST["lname"])) {
    $errorMSG .= "<li>Last Name is required</li>";
} else {
    $lname = $_POST["lname"];
}

/* address */
if (empty($_POST["address"])) {
    $errorMSG .= "<li>Address is required</li>";
} 
else {
    $address = $_POST["address"];
}

/* city */
if (empty($_POST["city"])) {
    $errorMSG .= "<li>City is required</li>";
} 
else {
    $city = $_POST["city"];
}

/* country */
if (empty($_POST["country"])) {
    $errorMSG .= "<li>Country is required</li>";
} 
else {
    $country = $_POST["country"];
}

/* postal code */
if (empty($_POST["postal_code"])) {
    $errorMSG .= "<li>Postal Code is required</li>";
} 
else {
    $postal_code = $_POST["postal_code"];
}

/* phone number */
if (empty($_POST["phone_number"])) {
    $errorMSG .= "<li>Phone Number is required</li>";
} 
else {
    $phone_number = $_POST["phone_number"];
}



if(empty($errorMSG))
{
$sql = "INSERT INTO orders (fname,lname,address,city,country,postal_code,phone_number)
VALUES ('$fname','$lname','$address','$city','$country','$postal_code','$phone_number')";

if ($conn->query($sql) === TRUE) {
  $msg =  "Your Order is Confirmed.";

   echo json_encode(['code'=>200, 'msg'=>$msg]);
    exit;
  
} 
else 
{
  
    echo json_encode(['code'=>404, 'msg'=>$conn->error]);
}
    
}
else 
{
    
      echo json_encode(['code'=>404, 'msg'=>$errorMSG]);
}




?>
